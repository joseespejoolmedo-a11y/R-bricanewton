# PixelAula iPad

Aplicación web para anonimizar caras en vídeos escolares desde un iPad Pro, Mac o PC.

## Características

- Carga vídeos desde Archivos/Fotos.
- Detección automática de caras con MediaPipe Face Detection.
- Pixelado fuerte, difuminado fuerte u óvalo negro.
- Máscaras manuales con dedo o Apple Pencil.
- Procesamiento local en el navegador.
- Exportación del vídeo anonimizado si Safari/Chrome soporta `MediaRecorder`.

## Uso en iPad Pro

1. Abre la web desde Safari.
2. Pulsa **Seleccionar vídeo**.
3. Pulsa **Detectar caras**.
4. Pulsa **Play** para revisar.
5. Añade máscaras manuales si alguna cara no se detecta.
6. Pulsa **Exportar vídeo anonimizado**.
7. Descarga el resultado.

## Publicar en GitHub Pages

1. Crea un repositorio en GitHub, por ejemplo `pixelaula-ipad`.
2. Sube estos archivos:
   - `index.html`
   - `style.css`
   - `app.js`
3. En GitHub, entra en:
   - Settings
   - Pages
   - Deploy from branch
   - Branch: `main`
   - Folder: `/root`
4. Abre la URL pública que GitHub te dé.

## Avisos importantes

- Revisa siempre el vídeo completo antes de compartirlo.
- Para menores, usa intensidad alta.
- La detección automática puede fallar con caras pequeñas, de perfil, tapadas o movidas.
- La exportación con sonido depende del navegador y de la versión de iPadOS.
- Si Safari no exporta bien, prueba Chrome para iPad o exporta sin sonido.
