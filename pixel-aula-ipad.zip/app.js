const els = {
  input: document.getElementById("videoInput"),
  video: document.getElementById("video"),
  canvas: document.getElementById("canvas"),
  viewer: document.getElementById("viewer"),
  play: document.getElementById("playBtn"),
  pause: document.getElementById("pauseBtn"),
  detect: document.getElementById("detectBtn"),
  snapshot: document.getElementById("snapshotBtn"),
  seek: document.getElementById("seek"),
  current: document.getElementById("current"),
  total: document.getElementById("total"),
  effect: document.getElementById("effect"),
  strength: document.getElementById("strength"),
  showBoxes: document.getElementById("showBoxes"),
  includeAudio: document.getElementById("includeAudio"),
  manual: document.getElementById("manualBtn"),
  clearManual: document.getElementById("clearManualBtn"),
  export: document.getElementById("exportBtn"),
  download: document.getElementById("download"),
  status: document.getElementById("status"),
};

const ctx = els.canvas.getContext("2d", { willReadFrequently: true });

let faceDetection = null;
let detectedFaces = [];
let detecting = false;
let animationId = null;
let manualMode = false;
let drawing = false;
let startPoint = null;
let manualMasks = [];
let exportRecorder = null;
let exportChunks = [];
let originalObjectURL = null;

function setStatus(text){ els.status.textContent = text; }

function formatTime(sec){
  if (!isFinite(sec)) return "00:00";
  const m = Math.floor(sec / 60).toString().padStart(2,"0");
  const s = Math.floor(sec % 60).toString().padStart(2,"0");
  return `${m}:${s}`;
}

function enableControls(enabled){
  [els.play, els.pause, els.detect, els.snapshot, els.seek, els.manual, els.clearManual, els.export].forEach(b => b.disabled = !enabled);
}

async function setupFaceDetection(){
  if (faceDetection) return;
  faceDetection = new FaceDetection({
    locateFile: file => `https://cdn.jsdelivr.net/npm/@mediapipe/face_detection/${file}`
  });
  faceDetection.setOptions({
    model: "short",
    minDetectionConfidence: 0.55
  });
  faceDetection.onResults(results => {
    detectedFaces = results.detections || [];
  });
}

function fitCanvasToVideo(){
  const v = els.video;
  const w = v.videoWidth || 1280;
  const h = v.videoHeight || 720;
  if (els.canvas.width !== w || els.canvas.height !== h){
    els.canvas.width = w;
    els.canvas.height = h;
  }
}

function drawFrame(){
  const v = els.video;
  if (!v.videoWidth) {
    animationId = requestAnimationFrame(drawFrame);
    return;
  }

  fitCanvasToVideo();
  ctx.drawImage(v, 0, 0, els.canvas.width, els.canvas.height);

  const boxes = getFaceBoxes();
  boxes.forEach(box => anonymizeBox(box, false));
  manualMasks.forEach(box => anonymizeBox(box, true));

  if (els.showBoxes.checked){
    drawBoxes(boxes, "rgba(20,164,77,.95)");
    drawBoxes(manualMasks, "rgba(242,183,5,.95)");
  }

  if (v.duration){
    els.seek.value = Math.floor((v.currentTime / v.duration) * 1000);
    els.current.textContent = formatTime(v.currentTime);
  }

  animationId = requestAnimationFrame(drawFrame);
}

function getFaceBoxes(){
  const w = els.canvas.width;
  const h = els.canvas.height;
  return detectedFaces.map(d => {
    const b = d.boundingBox;
    let x = (b.xCenter - b.width / 2) * w;
    let y = (b.yCenter - b.height / 2) * h;
    let bw = b.width * w;
    let bh = b.height * h;

    // Ampliación de seguridad: cubre pelo, orejas, barbilla y movimiento leve.
    const padX = bw * 0.30;
    const padY = bh * 0.38;

    x -= padX;
    y -= padY;
    bw += padX * 2;
    bh += padY * 2;

    return clampBox({x,y,w:bw,h:bh});
  });
}

function clampBox(b){
  const W = els.canvas.width;
  const H = els.canvas.height;
  let x = Math.max(0, b.x);
  let y = Math.max(0, b.y);
  let w = Math.min(W - x, b.w);
  let h = Math.min(H - y, b.h);
  return {x,y,w,h};
}

function anonymizeBox(box, manual){
  if (box.w <= 2 || box.h <= 2) return;

  const effect = els.effect.value;
  const strength = Number(els.strength.value);

  ctx.save();
  ctx.beginPath();
  ctx.ellipse(box.x + box.w/2, box.y + box.h/2, box.w/2, box.h/2, 0, 0, Math.PI*2);
  ctx.clip();

  if (effect === "black"){
    ctx.fillStyle = "black";
    ctx.fillRect(box.x, box.y, box.w, box.h);
  } else if (effect === "blur"){
    const img = ctx.getImageData(box.x, box.y, box.w, box.h);
    ctx.filter = `blur(${Math.max(12, strength)}px)`;
    ctx.drawImage(els.canvas, box.x, box.y, box.w, box.h, box.x, box.y, box.w, box.h);
    ctx.filter = "none";
  } else {
    // Pixelado real: reduce y reescala sin suavizado.
    const scale = Math.max(0.03, 1 / strength);
    const sw = Math.max(2, Math.floor(box.w * scale));
    const sh = Math.max(2, Math.floor(box.h * scale));

    const off = document.createElement("canvas");
    off.width = sw;
    off.height = sh;
    const octx = off.getContext("2d");
    octx.imageSmoothingEnabled = false;
    octx.drawImage(els.canvas, box.x, box.y, box.w, box.h, 0, 0, sw, sh);

    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(off, 0, 0, sw, sh, box.x, box.y, box.w, box.h);
    ctx.imageSmoothingEnabled = true;
  }

  ctx.restore();
}

function drawBoxes(boxes, color){
  ctx.save();
  ctx.strokeStyle = color;
  ctx.lineWidth = Math.max(4, els.canvas.width / 300);
  boxes.forEach(b => {
    ctx.strokeRect(b.x, b.y, b.w, b.h);
  });
  ctx.restore();
}

async function detectLoop(){
  if (!detecting || els.video.paused || els.video.ended) return;
  try {
    await faceDetection.send({ image: els.video });
  } catch(e) {
    console.warn(e);
  }
  setTimeout(detectLoop, 80); // iPad: evita saturar Safari.
}

function canvasPointFromEvent(ev){
  const rect = els.canvas.getBoundingClientRect();
  const touch = ev.touches ? ev.touches[0] : ev;
  const x = (touch.clientX - rect.left) * (els.canvas.width / rect.width);
  const y = (touch.clientY - rect.top) * (els.canvas.height / rect.height);
  return {x, y};
}

function startManual(ev){
  if (!manualMode) return;
  ev.preventDefault();
  drawing = true;
  startPoint = canvasPointFromEvent(ev);
}

function moveManual(ev){
  if (!manualMode || !drawing) return;
  ev.preventDefault();
  const p = canvasPointFromEvent(ev);
  const x = Math.min(startPoint.x, p.x);
  const y = Math.min(startPoint.y, p.y);
  const w = Math.abs(startPoint.x - p.x);
  const h = Math.abs(startPoint.y - p.y);

  drawFrameOnce();
  ctx.strokeStyle = "rgba(242,183,5,.95)";
  ctx.lineWidth = 6;
  ctx.strokeRect(x,y,w,h);
}

function endManual(ev){
  if (!manualMode || !drawing) return;
  ev.preventDefault();
  drawing = false;
  const p = canvasPointFromEvent(ev.changedTouches ? ev.changedTouches[0] : ev);
  const x = Math.min(startPoint.x, p.x);
  const y = Math.min(startPoint.y, p.y);
  const w = Math.abs(startPoint.x - p.x);
  const h = Math.abs(startPoint.y - p.y);
  if (w > 20 && h > 20) {
    manualMasks.push(clampBox({x,y,w,h}));
    setStatus(`Máscara manual añadida. Total: ${manualMasks.length}`);
  }
  manualMode = false;
  els.manual.textContent = "✚ Añadir máscara";
}

function drawFrameOnce(){
  fitCanvasToVideo();
  ctx.drawImage(els.video, 0, 0, els.canvas.width, els.canvas.height);
  const boxes = getFaceBoxes();
  boxes.forEach(b => anonymizeBox(b, false));
  manualMasks.forEach(b => anonymizeBox(b, true));
  if (els.showBoxes.checked){
    drawBoxes(boxes, "rgba(20,164,77,.95)");
    drawBoxes(manualMasks, "rgba(242,183,5,.95)");
  }
}

els.input.addEventListener("change", async () => {
  const file = els.input.files?.[0];
  if (!file) return;

  if (originalObjectURL) URL.revokeObjectURL(originalObjectURL);
  originalObjectURL = URL.createObjectURL(file);

  els.video.src = originalObjectURL;
  els.video.muted = false;
  els.video.load();

  els.video.onloadedmetadata = async () => {
    fitCanvasToVideo();
    els.total.textContent = formatTime(els.video.duration);
    enableControls(true);
    setStatus("Vídeo cargado. Pulsa “Detectar caras” y después Play.");
    drawFrameOnce();
    await setupFaceDetection();
  };
});

els.play.addEventListener("click", async () => {
  await setupFaceDetection();
  detecting = true;
  await els.video.play();
  detectLoop();
  if (!animationId) drawFrame();
  setStatus("Reproduciendo y pixelando en tiempo real.");
});

els.pause.addEventListener("click", () => {
  els.video.pause();
  setStatus("Pausado. Puedes revisar o añadir máscaras manuales.");
});

els.detect.addEventListener("click", async () => {
  await setupFaceDetection();
  await faceDetection.send({ image: els.video });
  drawFrameOnce();
  setStatus(`Detección realizada en este fotograma. Caras encontradas: ${detectedFaces.length}`);
});

els.snapshot.addEventListener("click", async () => {
  await faceDetection.send({ image: els.video });
  drawFrameOnce();
  setStatus(`Fotograma revisado. Caras encontradas: ${detectedFaces.length}`);
});

els.seek.addEventListener("input", () => {
  if (!els.video.duration) return;
  els.video.currentTime = (Number(els.seek.value) / 1000) * els.video.duration;
});

els.video.addEventListener("seeked", async () => {
  if (faceDetection) await faceDetection.send({ image: els.video });
  drawFrameOnce();
});

els.manual.addEventListener("click", () => {
  manualMode = !manualMode;
  els.manual.textContent = manualMode ? "Toca y arrastra en el vídeo" : "✚ Añadir máscara";
  setStatus(manualMode ? "Dibuja un rectángulo sobre la cara con el dedo o Apple Pencil." : "Modo manual desactivado.");
});

els.clearManual.addEventListener("click", () => {
  manualMasks = [];
  drawFrameOnce();
  setStatus("Máscaras manuales borradas.");
});

["mousedown","touchstart"].forEach(e => els.canvas.addEventListener(e, startManual, {passive:false}));
["mousemove","touchmove"].forEach(e => els.canvas.addEventListener(e, moveManual, {passive:false}));
["mouseup","mouseleave","touchend"].forEach(e => els.canvas.addEventListener(e, endManual, {passive:false}));

async function exportVideo(){
  if (!els.video.src) return;
  setStatus("Exportando. No bloquees el iPad ni cambies de pestaña.");

  els.download.hidden = true;
  exportChunks = [];

  const mimeCandidates = [
    "video/mp4;codecs=h264",
    "video/mp4",
    "video/webm;codecs=vp9",
    "video/webm;codecs=vp8",
    "video/webm"
  ];
  const mimeType = mimeCandidates.find(t => MediaRecorder.isTypeSupported(t)) || "";

  const fps = 25;
  const canvasStream = els.canvas.captureStream(fps);

  // Intento de mantener audio: en iPad puede depender de Safari/iPadOS.
  if (els.includeAudio.checked && els.video.captureStream){
    try {
      const vStream = els.video.captureStream();
      vStream.getAudioTracks().forEach(t => canvasStream.addTrack(t));
    } catch(e) {
      console.warn("No se pudo añadir audio", e);
    }
  }

  try {
    exportRecorder = new MediaRecorder(canvasStream, mimeType ? { mimeType } : undefined);
  } catch(e) {
    setStatus("Este navegador no permite exportar vídeo con MediaRecorder. Prueba en Safari actualizado o Chrome.");
    return;
  }

  exportRecorder.ondataavailable = e => {
    if (e.data && e.data.size) exportChunks.push(e.data);
  };

  exportRecorder.onstop = () => {
    const type = mimeType.includes("mp4") ? "video/mp4" : "video/webm";
    const ext = type.includes("mp4") ? "mp4" : "webm";
    const blob = new Blob(exportChunks, { type });
    const url = URL.createObjectURL(blob);
    els.download.href = url;
    els.download.download = `video-anonimizado-pixelaula.${ext}`;
    els.download.hidden = false;
    setStatus(`Exportación terminada. Pulsa “Descargar resultado”. Formato: ${ext.toUpperCase()}`);
  };

  els.video.pause();
  els.video.currentTime = 0;
  await new Promise(resolve => els.video.onseeked = resolve);

  detecting = true;
  exportRecorder.start(1000);
  await els.video.play();

  const exportDetect = async () => {
    if (els.video.ended || els.video.paused) return;
    try { await faceDetection.send({ image: els.video }); } catch(e){}
    setTimeout(exportDetect, 80);
  };
  exportDetect();

  const stopWhenEnded = () => {
    if (els.video.ended) {
      detecting = false;
      exportRecorder.stop();
      els.video.removeEventListener("ended", stopWhenEnded);
    }
  };
  els.video.addEventListener("ended", stopWhenEnded);
}

els.export.addEventListener("click", exportVideo);

drawFrame();
